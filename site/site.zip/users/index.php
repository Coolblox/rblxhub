<?php
require ("/opt/htdocs/core/header.php");
require ("/opt/htdocs/core/nav.php");

$searchusername = $_GET['q'] ?? "";
$searchusername = mysqli_real_escape_string($connect, $searchusername);

$tuserq = mysqli_query($connect, "SELECT * FROM users WHERE username LIKE '%$searchusername%' ORDER BY lastseen DESC");
$usercount = mysqli_num_rows($tuserq);
$usersperpage = 10;
$pages = ceil($usercount / $usersperpage);
$page = $_GET['page'] ?? 1;
$page = intval($page);

if ($page < 1) {
  $page = 1;
}

if ($page >= $pages) {
  $page = $pages;
}

$offset = ($page * $usersperpage) - $usersperpage;

if ($offset < 1) {
  $offset = 0;
}
$userq = mysqli_query($connect, "SELECT * FROM users  WHERE username LIKE '%$searchusername%' ORDER BY lastseen DESC LIMIT $usersperpage OFFSET $offset") or die(mysqli_error($connect));
?>
<div id="Body">
					
    
                    <div id="ctl00_cphRoblox_Panel1">
                    
                        <div id="BrowseContainer" style="text-align:center">
                         <form method="get">
                            <input name="ctl00$cphRoblox$FormSubmitWithoutOnClickEventWorkaround" type="text" value="http://aspnet.4guysfromrolla.com/articles/060805-1.aspx" id="ctl00_cphRoblox_FormSubmitWithoutOnClickEventWorkaround" style="visibility:hidden;display:none;"/>
                            <input name="q" type="text" maxlength="100" id="ctl00_cphRoblox_tbSearch"/>&nbsp;<a id="ctl00_cphRoblox_lbSearch" href="javascript:__doPostBack('ctl00$cphRoblox$lbSearch','')">Search</a>
                            <br/><br/>
                            
                              <?php
                              // 10
                              ?>      
                                    <div>
                        <table class="Grid" cellspacing="0" cellpadding="4" border="0" id="ctl00_cphRoblox_gvUsersBrowsed">
                            <tr class="GridHeader">
                                <th scope="col">Avatar</th><th scope="col"><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Sort$userName')">Name</a></th><th scope="col">Status</th><th scope="col"><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Sort$lastActivity')">Location / Last Seen</a></th>
                            </tr><tr class="GridItem">
                                <td>
                                                 <?php
        while ($user = mysqli_fetch_assoc($userq)) {

          $membership = "";

          if ($user['membership_type'] == "LEVEL_1") {
            $membership = "<span class=\"tag is-link\">Baron Membership</span>";
          } else if ($user['membership_type'] == "LEVEL_2") {
            $membership = "<span class=\"tag is-success\">Duke Membership</span>";
          } else if ($user['membership_type'] == "LEVEL_3") {
            $membership = "<span class=\"tag is-danger\">King Membership</span>";
          } else if ($user['membership_type'] == "PRO") {
            $membership = "<span class=\"tag is-primary\">Pro</span>";
          }

          $adminbadge = "";

          if ($user['permission_level'] == "ADMINISTRATOR") {
            $adminbadge = "<span class=\"tag is-danger\"><i class=\"fas fa-gavel\"></i>&nbsp;Admin</span>";
          }

          $onlinetext = ($user['lastseen'] + 300 >= time()) ? "<span class=\"UserOnlineStatus\">Online</span>" : "<span class=\"UserOfflineStatus\">Offline</span>";
          echo "<tr class='GridItem'>
    <td>
    <iframe height='60' width='60' src='' frameborder='0' scrolling='no'></iframe>
    </td>
    <td href='/user/?id=53' style='word-break: break-all;'>
    <a href='/user/?id=53'>{$user['username']}</a><br>
		<span>{$user['description']}</span>
    </td>
    <td><span>$onlinetext</span><br></td>
    <td><span>Website</span></td>
    </tr>";
        }
        ?>
        <div>
          <?php if ($page > 1)  {
            $pg = $page - 1;
            echo "<a href=\"/Users/?page=$pg\" style=\"text-decoration: none; color: blue;\"><< Previous</a>";
          }?> <td>Page: <?php echo $page ?> of <?php echo $pages ?></td>
          <?php if ($page < $pages)  {
            $pg = $page + 1;
            echo "<a href=\"/Users/?page=$pg\" style=\"text-decoration: none; color: blue;\">Next >></a>";
          }?>
                            </tr><tr class="GridPager">
                                <td colspan="4"><table border="0">
                                    <tr>
                                        <td><span>1</span></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$2')">2</a></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$3')">3</a></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$4')">4</a></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$5')">5</a></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$6')">6</a></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$7')">7</a></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$8')">8</a></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$9')">9</a></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$10')">10</a></td><td><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Page$11')">...</a></td>
                                    </tr>
                                </table></td>
                            </tr>
                        </table>
                    </div>
                                
                        </div>
                    
                </div>
                
                                </div>
<?php
require ("/opt/htdocs/core/footer.php");
?>