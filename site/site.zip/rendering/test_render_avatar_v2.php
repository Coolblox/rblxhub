<?php
include "/opt/htdocs/core/rendering.php";

RenderAvatarFromHashTEST("3427feb448b1935a83022a61935dee68", true);
echo "Done!";

?>