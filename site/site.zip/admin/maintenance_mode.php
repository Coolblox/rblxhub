<?php
include "/opt/htdocs/core/conn.php";

if (isset($_POST['sd'])) {
  $sdq = mysqli_query($connect, "UPDATE site_settings SET value='true' WHERE name='is_site_down'") or die(mysqli_error($connect));
  die("<br><br><br><br><br><center>Shutting Down Website.</center><meta http-equiv=\"refresh\" content=\"3;url=/maintenance\" />");
}

?>
<h2>Emergency Site Shutdown</h2>
<p>Pressing the button below will make the site shut down and visiting the site will redirect you to /maintenance.<br><b>
<form method="post">
  <br><br><br><br><br><br><input type="submit" name="sd" value="Maintenance Mode">
</form>
