<?php
//include "include.php";
include "/opt/htdocs/core/conn.php";

?>
<h2>Site Alert</h2>
<form method="post">
  <?php
  $calertxt = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM site_settings WHERE name='alert_text'"))['value'];
  if (isset($_POST['upd'])) {
    $text = htmlspecialchars(mysqli_real_escape_string($connect, $_POST['alert']));
    $visibility = ($_POST['show'] == 'ye');
    $vtext = $visibility ? "true" : "false";
    $upd = mysqli_query($connect, "UPDATE `site_settings` SET value='$vtext' WHERE name='is_alert_showing'") or die(mysqli_error($connect));
    $updt = mysqli_query($connect, "UPDATE `site_settings` SET value='$text' WHERE name='alert_text'") or die(mysqli_error($connect));
    echo "Updated alert.<br><br>";

  }
  ?>

  Alert text: <input type="text" maxlength="256" name="alert" value="<?php echo $calertxt ?>"><br><br>
  Show Site Alert?<br>
  <input type="radio" name="show" value="ye" checked> Yes<br>
  <input type="radio" name="show" value="nah"> No<br><br>
  <input type="submit" name="upd" value="Update Site Alert"><br>
</form>
