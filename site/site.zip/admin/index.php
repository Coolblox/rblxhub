<?php
require("/opt/htdocs/core/conn.php");
require("/opt/htdocs/core/logged_in.php");
require("/opt/htdocs/core/util_func.php");
require("/opt/htdocs/core/whitelist.php");
require("/opt/htdocs/core/rendering.php");
if (!$isloggedin) {
  die("<center>
    <h1>404 Not Found</h1>
  <hr>
    nginx/1.10.3
  </center>
");
}

if ($_USER['permission_level'] != "ADMINISTRATOR") {
  die("<center>
    <h1>404 Not Found</h1>
  <hr>
    nginx/1.10.3
  </center>
");
}
?>
<style>
    body {
        background-color: #f3f3f3;
    }
    #admin {
        width: 15%;
        background-color: #e8e8e8;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        z-index: 0;
    }
    #header {
        overflow: hidden;
    }
    #logo {
        text-align: center;
        padding: 5px 10px 0;
        border: 0;
    }
    #img {
        border: 0;
    }
</style>
<div id="admin">
<div id="header">
    <div id="logo">
        <a href="/">
        <img id="imglogo" src="../images/Logo_267_70.png" alt="<?=$sitename?> Admin">
        </a>
        <br>
        <a href="#">? abuse reports</a>&nbsp;
        <a href="#">? images</a>&nbsp;
        <a href="/admin/usermoderation.php">? users</a>&nbsp;
        <a href="/admin/maintenance_mode.php">? Maintenance Mode</a>&nbsp;
        <a href="/admin/site_alert.php">? Change Site Alert</a>&nbsp;
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <a href="/">- My <?=$sitename?></a>
    </div>
</div>
</div>