All html and css rights go to ROBLOX Corp.
----------------------------------------------
All backend code rights go to GREATBLOX Corp.
----------------------------------------------
All rights belong to their respective owners.