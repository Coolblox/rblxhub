<div id="Footer">
<hr/>
<p class="Legalese">
    <?=$sitename?>, "Online Building Toy", characters, logos, names, and all related indicia
    are trademarks of
    <a id="ctl00_rbxFooter_hlRobloxCorporation" href="info/About.html">ROBLOX Corporation</a>,
    ©2020-2021. Patents pending.<br/>
    <?=$sitename?> Corp. is not affliated with Lego, MegaBloks, Bionicle, Pokemon, Nintendo, Lincoln Logs, Yu Gi Oh, K'nex, Tinkertoys, Erector Set, or the Pirates of the Caribbean. ARrrr!<br/>
    Use of this site signifies your acceptance of the
    <a id="ctl00_rbxFooter_hlTermsOfService" href="info/TermsOfService.html">Terms and Conditions</a>.<br/>
    <a id="ctl00_rbxFooter_hlPrivacyPolicy" href="info/Privacy.html">Privacy Policy</a>
    &nbsp;|&nbsp; <a href="mailto:info@roblox.com">Contact Us</a> &nbsp;|&nbsp;
    <a id="ctl00_rbxFooter_hlAboutRoblox" href="info/About.html">About Us</a>
    &nbsp;|&nbsp;
    <a id="ctl00_rbxFooter_HyperLink1" href="info/Jobs.html">Jobs</a></p>
				</div>
			</div>
        <script src="urchin.js" type="text/javascript"></script>
        <script type="text/javascript">_uacct="UA-486632-1"; _udn="roblox.com"; urchinTracker(); __utmSetVar('Visitor/Anonymous');</script>
<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value=""/>
<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="OJvJtWMwtBVgUb6f2D+GOFazj4ASR4hHiMEFS1TaH9/xamwLdRaWhEyjfx1UCG2l"/>
<script type="text/javascript">
<!--
__utmSetVar('Ads/Banner');Roblox.Controls.Image.IE6Hack($get('ctl00_rbxImage_Logo'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_ImageFigure'));Sys.Application.initialize();
// -->
</script>
</form>
	<center><font size="2"><?=$sitename?> is based off of <a href="https://www.roblox.com/">ROBLOX</a> in 2008.</font></center>