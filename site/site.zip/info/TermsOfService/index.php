<?php
require ("/opt/htdocs/core/conn.php");
require ("/opt/htdocs/core/header.php");
?>
