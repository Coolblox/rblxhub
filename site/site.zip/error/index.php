<?php
include ("/opt/htdocs/core/header.php");
include ("/opt/htdocs/core/nav.php");
?>
<div id="Body">

    <p>
        &nbsp;</p>
    <p>
        &nbsp;</p>
    <center>
<font size="4">
    <b> An Error occured! We're sorry. </b>
</font>
</center>

    <p>
        &nbsp;</p>
    <p>
        &nbsp;</p>

				</div>
<?php
include ("/opt/htdocs/core/footer.php");
?>