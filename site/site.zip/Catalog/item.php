<?php
include "../core/header.php";
include "../core/nav.php";
$itemid = $_GET['id'] ?? 0;
$itemid = intval($itemid);

$itemq = mysqli_query($connect, "SELECT * FROM assets WHERE id='$itemid'") or die(mysqli_error($connect));

if (mysqli_num_rows($itemq) < 1) {
  //Item doesn't exist.

  header("Location: /Shop/");
  die("<script>document.location = \"/Shop/\"</script>");
}

$item = mysqli_fetch_assoc($itemq);

$creator = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM users WHERE id='{$item['creator']}'"));

$thumburl = "/assets/thumbnails/catalog/". $item['id'] .".png";

$canbuy = true;

if ($isloggedin) {
  if (mysqli_num_rows(mysqli_query($connect, "SELECT * FROM owneditems WHERE userid='{$_USER['id']}' AND assetid='{$item['id']}'")) > 0) {
      $canbuy = false;
  }
} else {
  $canbuy = false;
}
$soldout = false;

if (boolval($item['is_limited'])) {
  if ($item['sales'] >= $item['total_stock']) {
    $canbuy = false;
    $soldout = true;
  }
}

if ($item['onsale_until'] < time() && $item['onsale_until'] != 0) {
  $canbuy = false;
  $soldout = true;
}

if ($item['moderation_status'] == "REJECTED") {
  $thumburl = "/images/notfound.png";
}

if ($item['moderation_status'] == "PENDING") {
  $thumburl = "/images/unavail.png";
}



$currency_icon_url = ($item['currency'] == "Robux") ? "https://social-paradise.com/images/icons/brick.png" : "https://social-paradise.com/images/icons/stud.png";

$isitemowned = false;

if ($isloggedin) {
  $isitemowned = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM owneditems WHERE userid='{$_USER['id']}' AND assetid='{$item['id']}'")) > 0;
}



$commentq = mysqli_query($connect, "SELECT * FROM comments WHERE assetid='{$item['id']}' ORDER BY id DESC") or die(mysqli_error($connect));

if (isset($_POST['ok'])) {
  $comment = $_POST['comment'];

  $comment = htmlspecialchars(mysqli_real_escape_string($connect, $comment));

  $newcomment = $comment;

  $p = FilterString($newcomment);
  while (FilterString($newcomment) != "OK") {
    $profanity = FilterString($newcomment);
    $repl = str_repeat("*", strlen($profanity));
    $newcomment = str_replace($profanity, $repl, $newcomment);
  }

$time_rn = time();

  mysqli_query($connect, "INSERT INTO `comments`
    (`id`, `userid`, `assetid`, `content`, `time_posted`) VALUES
    (NULL, '{$_USER['id']}','{$item['id']}','$newcomment','$time_rn')")
  or die(mysqli_error($connect));
  die("<script>document.location = document.location</script>");
}

$commentamt = mysqli_num_rows($commentq);

$ownedamt = 0;
$isonsale = false;

if ($item['is_limited']) {
if ((mysqli_num_rows(mysqli_query($connect, "SELECT * FROM on_sale_limiteds WHERE item_id='$itemid' ORDER BY price ASC")) != 0) && ($item['sales'] >= $item['total_stock'])) {
  $isonsale = true;
  $best_lim = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM on_sale_limiteds WHERE item_id='$itemid' ORDER BY price ASC"));
}}

if ($isloggedin) {
  $ownedamt = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `owneditems` WHERE `userid`='{$_USER['id']}' AND `assetid`='$itemid'"));
  if ($item['is_limited']) {
  if ($item['sales'] >= $item['total_stock']) {
    $canbuy = $isonsale;
  }}

}

if ($isonsale) {
  $currency_icon_url = "https://social-paradise.com/images/icons/brick.png";
  $item['price'] = $best_lim['price'];
}

if ($item['is_limited'] == 1) {
  $range = $_GET['range'] ?? 365*10;
  $range = intval($range);

  $min = floor((time() / 86400) - $range);

  $dataq = mysqli_query($connect, "SELECT * FROM `limited_sales` WHERE `item_id`='$itemid'") or die(mysqli_error($connect));

  if (mysqli_num_rows($dataq) == 0) {
    $chartData = "{x:0,y:0}";
  } else {
    $avgs = array();


    $first = true;
    while ($data = mysqli_fetch_assoc($dataq)) {
      if (!isset($avgs[$data['time']])) {
        $avgs[$data['time']] = $data['price'];
      } else {
        $newavg = ceil(($avgs[$data['time']] + $data['price']) / 2);
        $avgs[$data['time']] = $newavg;
      }
    }
    $chartData = "";
    $x = 0;
    foreach ($avgs as $key => $value) {
      $chartData .= "{x:$x,y:$value},";
      $x++;
    }

    $chartData = substr_replace($chartData ,"", -1);
  }

  $owners = mysqli_query($connect, "SELECT * FROM owneditems WHERE assetid='$itemid' ORDER BY serial ASC") or die(mysqli_error($connect));


}


?>
  <div id="Body">
    <style>
    #Item {
    font-family: Verdana, Sans-Serif;
    padding: 10px;
}
#ItemContainer {
    background-color: #eee;
    border: solid 1px #555;
    color: #555;
    margin: 0 auto;
    width: 620px;
}
#Actions {
    background-color: #fff;
    border-bottom: dashed 1px #555;
    border-left: dashed 1px #555;
    border-right: dashed 1px #555;
    clear: left;
    float: left;
    padding: 5px;
    text-align: center;
    min-width: 0;
    position: relative;
}
    </style>
	<div id="ItemContainer" style="float:left;width: 720px;">
	<h2><?php echo $item['name'] ?></h2>
	<div id="Item">
		<div id="Thumbnail">
			<a title="Bighead" style="display:inline-block;height:250px;width:250px;"><img src="<?php echo $thumburl ?>" border="0" id="img" alt="Bighead" style="display:inline-block;height:250px;width:250px;"></a>
		</div>
		<div id="Summary">
			<h3><?=$sitename?> <?php echo ucfirst($item['type']) ?></h3>
						<div id="RobuxPurchase">
				<div id="PriceInRobux">Bux: <?php echo $item['price']; ?></div>
<div id='BuyWithRobux'>
					<a onclick=';showPurchaseDiag(0);' class='Button'>Buy with Bux</a>
				</div>
			</div>			<br><br>
						<div id="Creator"><br><a href="/user/?id=13"><iframe src="https://web.archive.org/web/20110711055128im_/http://t7.roblox.com/Avatar-180x220-a4c138a9343e14c5357d62566d3c9c1b.Png" frameborder="0" scrolling="no" width="100" height="110"></iframe></a><br><span style="color:#555;">Creator: </span><a href="/User.php?id=<?php echo $creator['id'] ?>"><?php echo $creator['username'] ?></a></div>
			<div id="LastUpdate">Updated: <?php echo $item['updated'] ?></div>
			<div id="Favourites">Favorited: 0 times</div>
						<div>
				<div id="DescriptionLabel">Description:</div>
				<div id="Description"><?php echo $item['description'] ?></div>
			</div>
						<p>
				</p><div class="ReportAbusePanel">
					<span class="AbuseIcon"><a><img src="../images/abuse.gif" alt="Report Abuse" style="border-width:0px;"></a></span>
					<span class="AbuseButton"><a>Report Abuse</a></span>
				</div>
			<p></p>
		</div>
		<div id="Actions" style="width:240px;">
            	        <a href="#">Favorite</a>
	                            </div><div style="clear: both;"></div>

	</div>
</div>
<div style="clear:both;"></div>
<div id='itemPurchaseFade' style='position: fixed; z-index: 1; left: 0px; top: 0px; width: 100%; height: 100%; overflow: auto; background-color: rgba(100, 100, 100, 0.25); display: none;'>
	<div id='itemPurchase' class='anim' style='max-width: 325px; position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%);'>
		<div style='background-color: #FFFFE0; border:3px solid gray; box-shadow: black 5px 5px;'><div id='VerifyPurchaseTix' style='margin: 1.5em; display:none;'>
				<h3>Insufficient Funds</h3>
				<p>You need more Tix to purchase this item.</p>
				<p><input type='submit' name='oof' value='Cancel' onclick='$(&#39;#itemPurchaseFade&#39;).hide();' class='MediumButton' style='width:100%;'></p>
			</div>						<div id='PurchaseMessage' style='margin: 1.5em; display: none;'>
						    Thanks for buy this.
			</div>
		</div>        	</div>
</div>