<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <title>GREATBLOX Maintenance</title>
    <style type="text/css">
  .content { border: 1px solid rgb(153, 153, 153);
	width: 800px;
    margin-top: 0px;
    margin-bottom: 10px;
    background-color: rgb(255, 255, 255);
    margin-right: auto;
    margin-left: auto;
    text-align: justify;
    }
  .content h1 { font-family: Comic Sans MS,Geneva,Arial,Helvetica,sans-serif;
  	margin: 0px;
    padding: 3px 4px;
    font-size: 12pt;
    background-repeat: repeat-x;
    color: rgb(0, 0, 0);
    background-color: rgb(251, 242, 166);
    text-align: center;
    }
  .content h2 { margin: 0px 0px 0px 0px;
    padding: 1px 4px;
    background-color: rgb(191,191,191);
    font-family: Geneva,Arial,Helvetica,sans-serif;
    font-variant: small-caps;
    color: rgb(0, 0, 0);
    font-size: 16px;
    text-align: center;
    }
  .content p {  font-family: Comic Sans MS,Geneva,Arial,Helvetica,sans-serif;
    margin: 5px;
    font-size: 11px;
    line-height: 1.5;
    padding-left: 5px;
    text-align: center;
    padding-right: 5px;
    }
    </style>
</head>
<body>
    <div align="center">
        <img src="/images/Logo_267_70.png">
        <div class="content">
            <h1>
                We are upgrading GREATBLOX!<br/>
                Stay tuned... We'll be back online soon.
            </h1>
            <h2>
                You will be redirected to GREATBLOX when we are back up.</h2>
            <p>
                <img src="/images/OH_NOES.png"></p>
        </div>
    </div>
    <script type="text/javascript">
window.window.setTimeout("", 30000);
    </script>
</html>