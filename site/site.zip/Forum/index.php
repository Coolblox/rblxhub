<?php
require ("/opt/htdocs/core/header.php");
require ("/opt/htdocs/core/nav.php");
$topic = $_GET['t'] ?? 1;

$topic = intval($topic);


$fq = mysqli_query($connect, "SELECT * FROM forum WHERE category='$topic' AND reply_to='0' ORDER BY `time_posted` DESC") or die(mysqli_error($connect));

$nowwww = new DateTime("@" . time());
$now = $nowwww->format('d F Y G:i');

$btthreads = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='1' AND reply_to='0'"));
$btreplies = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='1'"));

$hthreads = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='2' AND reply_to='0'"));
$hreplies = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='2'"));

$rnthreads = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='3' AND reply_to='0'"));
$rnreplies = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='3'"));

$sthreads = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='4' AND reply_to='0'"));
$sreplies = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='4'"));

$otthreads = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='5' AND reply_to='0'"));
$otreplies = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='5'"));

$rpthreads = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='6' AND reply_to='0'"));
$rpreplies = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='6'"));

$rmcthreads = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='7' AND reply_to='0'"));
$rmcreplies = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM forum WHERE category='7'"));



$lp1q = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM forum WHERE category='1' ORDER BY id DESC LIMIT 1"));
$lp1a = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM users WHERE id='{$lp1q['author']}'"));
$lp1t = time_elapsed_string("@{$lp1q['time_posted']}");
$lp1 = "<center>$lp1t<br>by <a href=\"/User/?id={$lp1q['author']}\">{$lp1a['username']}</a></center>";

$lp2q = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM forum WHERE category='2' ORDER BY id DESC LIMIT 1"));
$lp2a = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM users WHERE id='{$lp2q['author']}'"));
$lp2t = time_elapsed_string("@{$lp2q['time_posted']}");
$lp2 = "<center>$lp2t<br>by <a href=\"/User/?id={$lp2q['author']}\">{$lp2a['username']}</a></center>";

$lp3q = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM forum WHERE category='3' ORDER BY id DESC LIMIT 1"));
$lp3a = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM users WHERE id='{$lp3q['author']}'"));
$lp3t = time_elapsed_string("@{$lp3q['time_posted']}");
$lp3 = "<center>$lp3t<br>by <a href=\"/User/?id={$lp3q['author']}\">{$lp3a['username']}</a></center>";

$lp4q = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM forum WHERE category='4' ORDER BY id DESC LIMIT 1"));
$lp4a = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM users WHERE id='{$lp4q['author']}'"));
$lp4t = time_elapsed_string("@{$lp4q['time_posted']}");
$lp4 = "<center>$lp4t<br>by <a href=\"/User/?id={$lp4q['author']}\">{$lp4a['username']}</a></center>";

$lp5q = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM forum WHERE category='5' ORDER BY id DESC LIMIT 1"));
$lp5a = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM users WHERE id='{$lp5q['author']}'"));
$lp5t = time_elapsed_string("@{$lp5q['time_posted']}");
$lp5 = "<center>$lp5t<br>by <a href=\"/User/?id={$lp5q['author']}\">{$lp5a['username']}</a></center>";

$lp6q = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM forum WHERE category='6' ORDER BY id DESC LIMIT 1"));
$lp6a = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM users WHERE id='{$lp6q['author']}'"));
$lp6t = time_elapsed_string("@{$lp6q['time_posted']}");
$lp6 = "<center>$lp6t<br>by <a href=\"/User/?id={$lp6q['author']}\">{$lp6a['username']}</a></center>";

$lp7q = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM forum WHERE category='7' ORDER BY id DESC LIMIT 1"));
$lp7a = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM users WHERE id='{$lp7q['author']}'"));
$lp7t = time_elapsed_string("@{$lp7q['time_posted']}");
$lp7 = "<center>$lp7t<br>by <a href=\"/User/?id={$lp7q['author']}\">{$lp7a['username']}</a></center>";
?>
<link rel="stylesheet" href="http://coolblox.net/Forum/api/skins/default/style/default.css" type="text/css"/>
<div id="Body">

				</div>